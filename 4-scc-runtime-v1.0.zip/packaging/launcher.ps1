$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataRoot = Join-Path $env:LOCALAPPDATA 'SubscriptionControlCenter\data'
New-Item -ItemType Directory -Force -Path $DataRoot | Out-Null
$env:SCC_DATA = $DataRoot
$env:PORT = '4190'
$env:HOST = '127.0.0.1'
# Connector secrets live only in this local file (KEY=value lines, SCC_SECRET_*), never in the database.
$secrets = Join-Path $DataRoot 'secrets.env'
if (Test-Path $secrets) { Get-Content $secrets | ForEach-Object { if ($_ -match '^\s*(SCC_SECRET_[A-Za-z0-9_]+)=(.+)$') { Set-Item -Path ('Env:' + $Matches[1]) -Value $Matches[2].Trim() } } }
$tokenFile = Join-Path $DataRoot 'FIRST-SETUP.txt'
if (!(Test-Path $tokenFile)) {
  $bytes = New-Object byte[] 18; (New-Object Security.Cryptography.RNGCryptoServiceProvider).GetBytes($bytes)
  $tok = ([BitConverter]::ToString($bytes) -replace '-', '').ToLower()
  Set-Content -Path $tokenFile -Value ("Subscription Control Center first setup`r`nOpen http://localhost:4190 and create the owner account with this one-time setup code:`r`n$tok`r`nKeep this file private.")
  Set-Content -Path (Join-Path $DataRoot 'setup.token') -Value $tok
  $first = $true
}
$env:SCC_SETUP_TOKEN = (Get-Content (Join-Path $DataRoot 'setup.token') -ErrorAction SilentlyContinue)
try {
  $r = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4190/' -TimeoutSec 1
  if ($r.Content -notmatch 'Subscription Control Center') { throw 'Port 4190 is in use by another application.' }
  Start-Process 'http://localhost:4190'; exit 0
} catch { if ($_.Exception.Message -match 'Port 4190') { throw } }
$log = Join-Path $DataRoot 'server.log'; $errlog = Join-Path $DataRoot 'server-error.log'
$p = Start-Process -FilePath (Join-Path $AppRoot 'runtime\node.exe') -ArgumentList ('"' + (Join-Path $AppRoot 'server.mjs') + '"') -WorkingDirectory $AppRoot -PassThru -WindowStyle Hidden -RedirectStandardOutput $log -RedirectStandardError $errlog
$ready = $false
for ($i = 0; $i -lt 60; $i++) { Start-Sleep -Milliseconds 250; if ($p.HasExited) { break }; try { $r = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:4190/' -TimeoutSec 1; if ($r.Content -match 'Subscription Control Center') { $ready = $true; break } } catch {} }
if (!$ready) { Start-Process notepad.exe $errlog; throw 'Subscription Control Center did not start. See the error log.' }
Set-Content -Path (Join-Path $DataRoot 'server.pid') -Value $p.Id
if ($first) { Start-Process notepad.exe $tokenFile }
Start-Process 'http://localhost:4190'
