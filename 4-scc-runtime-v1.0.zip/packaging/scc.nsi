Unicode True
!include "MUI2.nsh"
Name "Subscription Control Center"
OutFile "SCC-Setup-1.0.0-x64.exe"
InstallDir "$LOCALAPPDATA\Programs\SubscriptionControlCenter"
RequestExecutionLevel user
SetCompressor /SOLID lzma
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp
!define MUI_FINISHPAGE_RUN_TEXT "Start Subscription Control Center"
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"
Section "App"
SetOutPath "$INSTDIR"
File /r "stage\*"
WriteUninstaller "$INSTDIR\Uninstall.exe"
CreateDirectory "$SMPROGRAMS\Subscription Control Center"
CreateShortcut "$SMPROGRAMS\Subscription Control Center\Subscription Control Center.lnk" "$WINDIR\System32\wscript.exe" '"$INSTDIR\Launch-SCC.vbs"'
CreateShortcut "$DESKTOP\Subscription Control Center.lnk" "$WINDIR\System32\wscript.exe" '"$INSTDIR\Launch-SCC.vbs"'
CreateShortcut "$SMPROGRAMS\Subscription Control Center\Stop.lnk" "$WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" '-NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1"'
CreateShortcut "$SMPROGRAMS\Subscription Control Center\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter" "DisplayName" "Subscription Control Center"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter" "UninstallString" '"$INSTDIR\Uninstall.exe"'
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter" "Publisher" "Alpha Blue Digital"
SectionEnd
Section "Uninstall"
ExecWait '"$WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1"'
Delete "$DESKTOP\Subscription Control Center.lnk"
RMDir /r "$SMPROGRAMS\Subscription Control Center"
RMDir /r "$INSTDIR"
MessageBox MB_OK "Program removed. Your data stays in %LOCALAPPDATA%\SubscriptionControlCenter\data and was not deleted."
SectionEnd
Function LaunchApp
Exec '"$WINDIR\System32\wscript.exe" "$INSTDIR\Launch-SCC.vbs"'
FunctionEnd
