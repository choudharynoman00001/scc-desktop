; SCC installer v5 candidate - compile-checked locally with makensis 3.08 (Ubuntu deb, unprivileged).
; - LogicLib == is case-insensitive (reviewer-corrected): no CharUpper, no System-call case hacks.
; - No StrContains / GetFullPathName / TrimNewlines (not available): ownership list is a
;   COMPILE-TIME include (uninstall-files.nsh, generated from the staged tree), not a runtime parse.
; - Shared validation at .onInit, directory-page leave (define directly above MUI_PAGE_DIRECTORY),
;   and Section pre-write.
; - Reparse/junction fail-closed: INSTDIR and inner runtime/lib/public checked before ANY delete.
Unicode True
!include "MUI2.nsh"
!include "LogicLib.nsh"
Name "Subscription Control Center"
OutFile "SCC-Setup-1.0.0-x64.exe"
InstallDir "$LOCALAPPDATA\Programs\SubscriptionControlCenter"
RequestExecutionLevel user
SetCompressor /SOLID lzma
!insertmacro MUI_PAGE_WELCOME
!define MUI_PAGE_CUSTOMFUNCTION_LEAVE DirLeave
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_FUNCTION LaunchApp
!define MUI_FINISHPAGE_RUN_TEXT "Start Subscription Control Center"
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

; IsUnder: $R6="1" if $R7(path) equals or is beneath $R8(root). LogicLib == is case-insensitive.
!macro _IsUnder
  StrLen $R5 $R7
  ${If} $R5 > 1
    StrCpy $R4 $R7 1 -1
    ${If} $R4 == "\"
      StrCpy $R7 $R7 -1
    ${EndIf}
  ${EndIf}
  StrCpy $R6 "0"
  ${If} $R7 == $R8
    StrCpy $R6 "1"
  ${Else}
    StrCpy $R5 "$R8\"
    StrLen $R4 $R5
    StrCpy $R3 $R7 $R4
    ${If} $R3 == $R5
      StrCpy $R6 "1"
    ${EndIf}
  ${EndIf}
!macroend

; Refuse (SetErrorLevel 5 + Abort) if the given existing path is a junction/reparse point.
!macro _RefuseIfReparse PATH
  ${If} ${FileExists} "${PATH}"
    System::Call 'kernel32::GetFileAttributesW(w "${PATH}") i .R1'
    ${If} $R1 != -1
      IntOp $R2 $R1 & 0x400
      ${If} $R2 != 0
        MessageBox MB_ICONSTOP "Folder ${PATH} is a junction or reparse point. Nothing was deleted."
        SetErrorLevel 5
        Abort
      ${EndIf}
    ${EndIf}
  ${EndIf}
!macroend

; Same refusal for INSTALL (write-through): refuse before any SetOutPath/File write.
!macro _RefuseIfReparseWrite PATH
  ${If} ${FileExists} "${PATH}"
    System::Call 'kernel32::GetFileAttributesW(w "${PATH}") i .R1'
    ${If} $R1 != -1
      IntOp $R2 $R1 & 0x400
      ${If} $R2 != 0
        MessageBox MB_ICONSTOP "Folder ${PATH} is a junction or reparse point. No files were written."
        SetErrorLevel 5
        Abort
      ${EndIf}
    ${EndIf}
  ${EndIf}
!macroend

; $R0 = "ok" or rejection message. Validates $INSTDIR.
Function ValidateInstallDir
  StrLen $R1 $INSTDIR
  ${If} $R1 < 10
    StrCpy $R0 "Install location is not allowed. Choose a dedicated folder."
    Return
  ${EndIf}
  StrCpy $R8 "$WINDIR"
  StrCpy $R7 "$INSTDIR"
  !insertmacro _IsUnder
  ${If} $R6 == "1"
    StrCpy $R0 "Install location is inside the Windows folder. Choose a dedicated folder."
    Return
  ${EndIf}
  StrCpy $R8 "$PROGRAMFILES"
  StrCpy $R7 "$INSTDIR"
  !insertmacro _IsUnder
  ${If} $R6 == "1"
    StrCpy $R0 "Install location is inside Program Files. Choose a per-user folder."
    Return
  ${EndIf}
  StrCpy $R8 "$PROGRAMFILES64"
  StrCpy $R7 "$INSTDIR"
  !insertmacro _IsUnder
  ${If} $R6 == "1"
    StrCpy $R0 "Install location is inside Program Files. Choose a per-user folder."
    Return
  ${EndIf}
  ; exact user roots only (descendants allowed: default lives under $PROFILE\AppData\Local)
  ${If} $INSTDIR == $PROFILE
  ${OrIf} $INSTDIR == $DESKTOP
  ${OrIf} $INSTDIR == $DOCUMENTS
    StrCpy $R0 "Install location is a user root folder. Choose a dedicated subfolder."
    Return
  ${EndIf}
  ; occupied foreign folder: refuse. Ours = marker, or STRONG legacy fingerprint (all four files).
  ${If} ${FileExists} "$INSTDIR\*"
  ${AndIfNot} ${FileExists} "$INSTDIR\scc-owned.marker"
    ${IfNot} ${FileExists} "$INSTDIR\server.mjs"
    ${OrIfNot} ${FileExists} "$INSTDIR\runtime\node.exe"
    ${OrIfNot} ${FileExists} "$INSTDIR\lib\db.mjs"
    ${OrIfNot} ${FileExists} "$INSTDIR\public\ab-icon.png"
      StrCpy $R0 "This folder already contains other files. Choose an empty or new folder."
      Return
    ${EndIf}
  ${EndIf}
  StrCpy $R0 "ok"
FunctionEnd

Function .onInit
  Call ValidateInstallDir
  ${If} $R0 != "ok"
    MessageBox MB_ICONSTOP "$R0"
    SetErrorLevel 2
    Abort
  ${EndIf}
FunctionEnd

Function DirLeave
  Call ValidateInstallDir
  ${If} $R0 != "ok"
    MessageBox MB_ICONSTOP "$R0"
    Abort
  ${EndIf}
FunctionEnd

Section "App"
Call ValidateInstallDir
${If} $R0 != "ok"
  MessageBox MB_ICONSTOP "$R0"
  SetErrorLevel 2
  Abort
${EndIf}
; junction fail-closed BEFORE any write (root + inner components File /r would write through)
!insertmacro _RefuseIfReparseWrite "$INSTDIR"
!insertmacro _RefuseIfReparseWrite "$INSTDIR\runtime"
!insertmacro _RefuseIfReparseWrite "$INSTDIR\lib"
!insertmacro _RefuseIfReparseWrite "$INSTDIR\public"
SetOutPath "$INSTDIR"
File /r "stage\*"
FileOpen $9 "$INSTDIR\scc-owned.marker" w
FileWrite $9 "SubscriptionControlCenter/1.0 owned-install$\r$\n"
FileClose $9
WriteUninstaller "$INSTDIR\Uninstall.exe"
CreateDirectory "$SMPROGRAMS\Subscription Control Center"
CreateShortcut "$SMPROGRAMS\Subscription Control Center\Subscription Control Center.lnk" "$WINDIR\System32\wscript.exe" '"$INSTDIR\Launch-SCC.vbs"'
CreateShortcut "$DESKTOP\Subscription Control Center.lnk" "$WINDIR\System32\wscript.exe" '"$INSTDIR\Launch-SCC.vbs"'
CreateShortcut "$SMPROGRAMS\Subscription Control Center\Stop.lnk" "$WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" '-NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1"'
CreateShortcut "$SMPROGRAMS\Subscription Control Center\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter" "DisplayName" "Subscription Control Center"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter" "UninstallString" '"$INSTDIR\Uninstall.exe"'
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter" "Publisher" "Alpha Blue Digital"
WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter" "InstallLocation" '"$INSTDIR"'
SectionEnd

Section "Uninstall"
; marker gate: refuse anything not installed by v5+ (legacy v1 dirs are migrated by installing v5 over them)
${IfNot} ${FileExists} "$INSTDIR\scc-owned.marker"
  MessageBox MB_ICONSTOP "Uninstaller cannot verify this folder as a Subscription Control Center install. Nothing was deleted."
  SetErrorLevel 4
  Abort
${EndIf}
; junction fail-closed BEFORE any delete (root + every inner component we delete through)
!insertmacro _RefuseIfReparse "$INSTDIR"
!insertmacro _RefuseIfReparse "$INSTDIR\runtime"
!insertmacro _RefuseIfReparse "$INSTDIR\lib"
!insertmacro _RefuseIfReparse "$INSTDIR\public"
${If} ${FileExists} "$INSTDIR\stop.ps1"
  ExecWait '"$WINDIR\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\stop.ps1"'
${EndIf}
Delete "$DESKTOP\Subscription Control Center.lnk"
Delete "$SMPROGRAMS\Subscription Control Center\Subscription Control Center.lnk"
Delete "$SMPROGRAMS\Subscription Control Center\Stop.lnk"
Delete "$SMPROGRAMS\Subscription Control Center\Uninstall.lnk"
RMDir "$SMPROGRAMS\Subscription Control Center"
DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\SubscriptionControlCenter"
; compile-time owned list: exact Delete lines generated from the staged tree by the build
!include "uninstall-files.nsh"
Delete "$INSTDIR\scc-owned.marker"
Delete "$INSTDIR\Uninstall.exe"
; LEFTOVERS BY DESIGN: only the compile-time owned list above, the marker and Uninstall.exe are
; deleted. User data, foreign files, and any older-version (legacy v1) files NOT in the staged
; list are intentionally preserved; the non-recursive RMDir calls below only remove EMPTY dirs.
; This is not a clean sweep and is not reported as one.
RMDir "$INSTDIR\runtime"
RMDir "$INSTDIR\lib"
RMDir "$INSTDIR\public"
RMDir "$INSTDIR"
SectionEnd
Function LaunchApp
Exec '"$WINDIR\System32\wscript.exe" "$INSTDIR\Launch-SCC.vbs"'
FunctionEnd
