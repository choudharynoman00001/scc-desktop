# Operations notes (development build)
Backup: set SCC_BACKUP_DIR + SCC_BACKUP_HOURS. Files are VACUUM INTO copies, mode 0600, directory 0700. Keep a copy off the machine.
Restore: stop SCC, replace the database file with a backup copy, start SCC. Then: (1) rotate each connector secret/key id in the product and the SCC environment (replay-window state may roll back), (2) run Software > reconcile for each API product and review drift, (3) check the Access column "seen" dates. The restore drill is manual; an automated restore test is NOT built.
Owner payment self-verify: current behaviour is that super_admin may verify a payment they recorded themselves (billing role may not); the verify step is audit-logged. This is a single-owner convenience, not a segregation-of-duties control. A policy switch to forbid it is NOT built.
Open items: TOTP secrets are stored in the database unencrypted (an approved key flow is needed before encrypting); "extend" changes end date without a new period record (audit-logged only).

## TOTP key (SCC_TOTP_KEY) - lockout risk
- Required before any login with TOTP enabled. Without it the server answers 503 totp_key_not_configured.
- Keep it in the vault, as its own item. Never store it next to a DB backup or in the repo, logs or chat.
- If the key is lost, enabled TOTP logins cannot be verified. Recovery needs the key from the vault; keep two vault copies.
- Rotating the key requires users to re-enroll TOTP.
