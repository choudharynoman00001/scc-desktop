import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { openDb, nowIso, audit, verifyAuditChain, nextNo, toMinor, fromMinor, checkCurrency, httpErr, addMonths, CYCLE_MONTHS } from './lib/db.mjs';
import { callProduct, newRequestId } from './lib/connector.mjs';
const __dir = path.dirname(fileURLToPath(import.meta.url));
const ROLE_CAPS = {
  super_admin: ['read', 'customers', 'subs', 'billing', 'verify', 'access', 'products', 'staff', 'backup'],
  billing: ['read', 'customers', 'subs', 'billing', 'verify'],
  support: ['read', 'customers'],
  readonly: ['read'],
};
const can = (u, cap) => ROLE_CAPS[u.role].includes(cap);
function need(u, cap) { if (!can(u, cap)) throw httpErr(403, 'forbidden', 'your role cannot do this'); }
const scryptP = (pw, salt) => crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
export function hashPw(pw) { const s = crypto.randomBytes(16); return 's1$' + s.toString('hex') + '$' + scryptP(pw, s).toString('hex'); }
function checkPw(pw, st) { const [, s, h] = st.split('$'); const a = scryptP(pw, Buffer.from(s, 'hex')), b = Buffer.from(h, 'hex'); return a.length === b.length && crypto.timingSafeEqual(a, b); }
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32enc(buf) { let bits = '', out = ''; for (const b of buf) bits += b.toString(2).padStart(8, '0'); for (let i = 0; i < bits.length; i += 5) out += B32[parseInt(bits.slice(i, i + 5).padEnd(5, '0'), 2)]; return out; }
function b32dec(s) { let bits = ''; for (const c of s) bits += B32.indexOf(c).toString(2).padStart(5, '0'); const o = []; for (let i = 0; i + 8 <= bits.length; i += 8) o.push(parseInt(bits.slice(i, i + 8), 2)); return Buffer.from(o); }
export function totp(secret, t = Date.now()) { const c = Buffer.alloc(8); c.writeBigUInt64BE(BigInt(Math.floor(t / 30000))); const h = crypto.createHmac('sha1', b32dec(secret)).update(c).digest(); const o = h[19] & 15; return String((h.readUInt32BE(o) & 0x7fffffff) % 1e6).padStart(6, '0'); }
const totpOk = (secret, code) => [-1, 0, 1].some((d) => totp(secret, Date.now() + d * 30000) === String(code));
export { b32enc };
import { makeCore } from './lib/core.mjs';
import { makeAccess } from './lib/access.mjs';
import { makeReports } from './lib/reports.mjs';
import { routesA } from './lib/routes_a.mjs';
import { routesB } from './lib/routes_b.mjs';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png' };
const SEC = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'" };
export function createApp({ dbFile, env = process.env, now = () => new Date() } = {}) {
  const db = openDb(dbFile);
  const core = makeCore(db, now), access = makeAccess(db, core, env, now), reports = makeReports(core, now);
  const backup = (dir) => { fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); const f = path.join(dir, 'scc-' + new Date().toISOString().replace(/[:.]/g, '-') + '.db'); db.exec("VACUUM INTO '" + f.replace(/'/g, "''") + "'"); fs.chmodSync(f, 0o600); const keep = Number(env.SCC_BACKUP_KEEP || 14), files = fs.readdirSync(dir).filter((x) => /^scc-.*\.db$/.test(x)).sort(); for (const old of files.slice(0, Math.max(0, files.length - keep))) fs.unlinkSync(path.join(dir, old)); return f; };
  const routes = []; const R = (method, pattern, fn, opts = {}) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn, ...opts });
  const seal = (plain) => { const k = env.SCC_TOTP_KEY; if (!/^[0-9a-f]{64}$/i.test(k || '')) throw httpErr(503, 'totp_key_not_configured', 'set SCC_TOTP_KEY (64 hex chars) in the server environment first'); const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', Buffer.from(k, 'hex'), iv), ct = Buffer.concat([c.update(plain, 'utf8'), c.final()]); return 'enc1:' + Buffer.concat([iv, c.getAuthTag(), ct]).toString('base64'); };
  const unseal = (s) => { if (!s) return s; if (!s.startsWith('enc1:')) return s; const k = env.SCC_TOTP_KEY; if (!/^[0-9a-f]{64}$/i.test(k || '')) throw httpErr(503, 'totp_key_not_configured'); const b = Buffer.from(s.slice(5), 'base64'), d = crypto.createDecipheriv('aes-256-gcm', Buffer.from(k, 'hex'), b.subarray(0, 12)); d.setAuthTag(b.subarray(12, 28)); return Buffer.concat([d.update(b.subarray(28)), d.final()]).toString('utf8'); };
  const D = { seal, unseal, db, core, env, now, access, reports, backup, hashPw, checkPw, totpOk, b32enc, ROLE_CAPS, need, nextNo };
  routesA(R, D); routesB(R, D);
  const server = http.createServer((req, res) => {
    const send = (st, body, h = {}) => { const isStr = typeof body === 'string' || Buffer.isBuffer(body); res.writeHead(st, { ...SEC, 'Cache-Control': 'no-store', ...(isStr ? {} : { 'Content-Type': 'application/json; charset=utf-8' }), ...h }); res.end(isStr ? body : JSON.stringify(body)); };
    const chunks = []; let size = 0, dead = false;
    req.on('data', (d) => { size += d.length; if (size > 1e6) { dead = true; send(413, { error: 'too_large' }); req.destroy(); } else chunks.push(d); });
    req.on('end', async () => {
      if (dead) return;
      let url; try { url = new URL(req.url, 'http://x'); decodeURIComponent(url.pathname); } catch { return send(400, { error: 'bad_url' }); }
      const p = url.pathname;
      if (!p.startsWith('/api/')) {
        const root = path.join(__dir, 'public'), full = path.normalize(path.join(root, p === '/' ? '/index.html' : p));
        if (!full.startsWith(root + path.sep) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) return send(404, 'not found', { 'Content-Type': 'text/plain' });
        return send(200, fs.readFileSync(full), { 'Content-Type': MIME[path.extname(full)] || 'application/octet-stream' });
      }
      const rt = routes.find((r) => r.method === req.method && r.re.test(p)); if (!rt) return send(404, { error: 'not_found' });
      try {
        const cookie = Object.fromEntries((req.headers.cookie || '').split(/;\s*/).filter(Boolean).map((x) => { const i = x.indexOf('='); return [x.slice(0, i), x.slice(i + 1)]; }));
        let body = {}; if (chunks.length) { if (!/^application\/json/.test(req.headers['content-type'] || '')) throw httpErr(415, 'json_only'); try { body = JSON.parse(Buffer.concat(chunks).toString()); } catch { throw httpErr(400, 'bad_json'); } if (body === null || typeof body !== 'object' || Array.isArray(body)) throw httpErr(400, 'bad_json'); }
        const ctx = { body, query: url.searchParams, params: rt.re.exec(p).groups || {}, ip: req.socket.remoteAddress || '' };
        if (req.method !== 'GET') { const o = req.headers.origin; if (o && new URL(o).host !== req.headers.host) throw httpErr(403, 'bad_origin'); }
        if (!rt.open) {
          const sid = cookie.scc_sid, s = sid && core.row('SELECT * FROM sessions WHERE id=? AND expires_at>?', sid, now().toISOString()), u = s && core.row("SELECT * FROM users WHERE id=? AND status='active'", s.user_id);
          if (!u) throw httpErr(401, 'login_required'); if (req.method !== 'GET' && req.headers['x-csrf'] !== s.csrf) throw httpErr(403, 'bad_csrf'); ctx.user = u; ctx.session = s; ctx.sid = sid;
        }
        const out = await rt.fn(ctx); let st = 200, b = out; const hdr = {};
        if (out && out.cookie) { b = out.body; hdr['Set-Cookie'] = out.cookie; } else if (out && out.status && out.body !== undefined) { st = out.status; b = out.body; }
        if (b && b.csv !== undefined) return send(200, b.csv, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="' + b.filename + '"' });
        if (b && b.html !== undefined) return send(200, b.html, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Security-Policy': "default-src 'none'; img-src 'self'; style-src 'unsafe-inline'", 'Cache-Control': 'no-store' });
        send(st, b, hdr);
      } catch (e) {
        if (e.status) return send(e.status, { error: e.code || 'error', message: e.message });
        if (/UNIQUE constraint/.test(e.message || '')) return send(409, { error: 'duplicate', message: 'already exists' });
        if (/constraint|abort/i.test(e.message || '')) return send(400, { error: 'invalid', message: 'value rejected' });
        console.error('internal', e.message); send(500, { error: 'internal' });
      }
    });
  });
  let bt = null;
  let rt = null; if (Number(env.SCC_RECONCILE_MINUTES) > 0) { const go = async () => { for (const p of core.all("SELECT id FROM products WHERE integration_type='api'")) { try { await access.reconcile(p.id, null); } catch (e) { console.error('reconcile failed', p.id, e.code || e.message); } } }; rt = setInterval(go, Number(env.SCC_RECONCILE_MINUTES) * 60000); rt.unref(); }
  if (env.SCC_BACKUP_DIR && Number(env.SCC_BACKUP_HOURS) > 0) { const go = () => { try { backup(env.SCC_BACKUP_DIR); } catch (e) { console.error('backup failed', e.message); } }; go(); bt = setInterval(go, Number(env.SCC_BACKUP_HOURS) * 3600e3); bt.unref(); }
  return { server, db, backup, close: () => { if (bt) clearInterval(bt); if (rt) clearInterval(rt); server.close(); db.close(); } };
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const dataDir = process.env.SCC_DATA || path.join(__dir, 'data'); fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  const app = createApp({ dbFile: path.join(dataDir, 'scc.db') });
  if (app.db.prepare('SELECT COUNT(*) n FROM users').get().n === 0 && !process.env.SCC_SETUP_TOKEN) { process.env.SCC_SETUP_TOKEN = crypto.randomBytes(12).toString('hex'); console.log('First run. Setup token (shown only here, do not share):', process.env.SCC_SETUP_TOKEN); }
  const port = Number(process.env.PORT || 3100), host = process.env.HOST || '127.0.0.1';
  app.server.listen(port, host, () => console.log('Subscription Control Center on http://' + host + ':' + port));
}
