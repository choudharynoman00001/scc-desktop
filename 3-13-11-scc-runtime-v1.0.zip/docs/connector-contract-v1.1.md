# Subscription Control Center - Connector Contract v1.1 (FREEZE CANDIDATE)
Supersedes v1 draft. Reference code: `lib/contract.mjs` (signing, verification, nonce store) and a conformance mock in `test/mockproduct.mjs`. No credentials in this document. Nothing here authorizes live suspension, payments, account-security changes, vendor-code edits or live writes to existing products.

## Decisions
- **Direction:** API-first. New products implement this API inside their own isolated build. No owner-password adapters, no stored owner credentials, until the user gives explicit permission. Existing products stay "manual-only" until an API is added with scoped approval.
- **Secrets:** the shared HMAC secret per product is never typed into an ordinary form or chat. The Center reads it from a server environment variable named in the product record (`secret_env`), supplied through the vault flow. Never stored in the Center DB, logs or audit.
- **Base path:** `/_scc/v1`. JSON (UTF-8) only. `Content-Type: application/json` on bodies.

## 1. Signing (canonical request)
Headers: `X-SCC-Key-Id`, `X-SCC-Timestamp` (unix seconds), `X-SCC-Nonce` (16-32 random bytes, hex encoded = 32-64 hex chars, lowercase), `X-SCC-Signature` (hex).
String to sign, joined by `\n`:
1. HTTP method, upper case
2. raw request path exactly as sent (not decoded, no query), must start `/_scc/v1`
3. canonical query: each key and value percent-encoded per RFC 3986 (uppercase hex, `!'()*` also encoded), pairs sorted by key then value, joined `&`; empty string if none
4. timestamp
5. nonce
6. lowercase hex SHA-256 of the raw body bytes (empty body = SHA-256 of empty string)
Signature = HMAC-SHA256(secret, string), hex. Compare in constant time.
Reject: missing headers/unknown key (401 missing_auth/unknown_key), timestamp skew > 300 s (401 stale_timestamp), bad signature (401 bad_signature).

## 2. Nonce vs idempotency (two different things)
- **Nonce** = replay protection for ONE signed transmission. Stored only after the signature is valid, kept 900 s (more than 2x the skew window, so no replay inside the valid window can pass), persisted so it survives restart. Same nonce twice -> 401 `nonce_replayed`. `addIfAbsent` must be atomic (concurrent replays: exactly one wins). Nonces are namespaced by key id; each key id belongs to ONE product and environment.
- **Fail closed:** if the nonce store cannot be read or written, the product answers 503 `nonce_store_unavailable` and performs no action; a corrupt store file stops startup, it is never treated as empty.
- **Restore/reset:** if the nonce store is missing or restored from a backup, set `notBefore = restore/start time` and reject any request whose timestamp is earlier (401 `before_store_floor`). The idempotency store (request_id results) must be restored in the same transaction/backup as the business data so a restored product never re-executes an old request_id differently.
- **Idempotency** = safe retry of the same business request. A retry is a NEW transmission (new timestamp, new nonce, new signature) with the SAME `request_id`. 
- Every mutating call carries `request_id` (UUID, in body). The product stores `request_id -> {payload_hash, response}` for at least 30 days.
  - same request_id + same payload hash -> return the stored response, no second effect (200/201 same body, header `Idempotent-Replay: true`).
  - same request_id + DIFFERENT payload hash -> 409 `request_id_conflict`, no effect.

## 3. Endpoints
- `GET /health` -> `{ok:true, product, version, contract:"scc-1.1"}`
- `GET /accounts/{external_ref}` -> `{external_ref, state:"active|suspended|expired|absent", state_changed_at, valid_until|null}`
- `PUT /accounts/{external_ref}` `{request_id, name, valid_until?, grace_until?}` -> create/update entitlement record (201/200). Does NOT create or change customer passwords.
- `POST /accounts/{external_ref}/suspend` `{request_id, reason, actor}` -> `{state:"suspended"}`. Blocks login/use only. Data and passwords untouched.
- `POST /accounts/{external_ref}/restore` `{request_id, actor}` -> `{state:"active"}`. **Expired policy:** if `valid_until` has passed (and `grace_until` too) restore returns 409 `entitlement_expired`; the Center must first renew/extend (PUT new valid_until), then restore. Restore never silently extends validity.
- `POST /accounts/{external_ref}/revoke-sessions` `{request_id, actor}` -> `{revoked:n}`
- `GET /accounts?cursor=` -> `{accounts:[...], next_cursor}` (reconciliation)
Errors: `{error:code, message}`; 404 unknown account on suspend/restore; 400 invalid body; 5xx on product failure.
Multi-tenant products: `external_ref` is the tenant id; acting on A never changes B.

## 4. Truthfulness rules (Center side)
- After any write the Center re-reads `GET /accounts/{ref}`. State shown = product-reported state, never the Center's intent.
- Timeout/5xx/bad signature/state mismatch -> action result `failed`/`unconfirmed`, access state `unknown`. Never "suspended".
- Connection status per product: Connected (last /health ok), Error, Manual action required, Not integrated. Every call logged (method, path, status, request_id; no secrets, no bodies with personal data beyond reason).

## 5. Alternative: signed entitlement token (for products that cannot expose an API)
Ed25519-signed `{v:1, sub, product, tenant, status, valid_until, grace_until}`; the product verifies with the Center's public key and enforces `valid_until` at login; it must document fail-safe behavior when no fresh token exists. Not implemented in the Center phase 1-3; reserved.

## 6. Conformance tests (builder deliverable, mirrors `test/conformance.test.mjs` in the Center repo)
1. /health ok; bad signature, stale timestamp, replayed nonce each rejected.
2. Query order/encoding differences that change canonical form are rejected; same logical query in any order verifies.
3. Nonce store survives a restart (replay after restart still rejected).
4. Same request_id + same payload = one effect; same request_id + different payload = 409.
5. Suspend A leaves B active; restore A returns active; restore of expired entitlement = 409.
6. Suspended account cannot sign in; its data remains.
7. Failure mid-suspend leaves state unchanged and truthfully readable.
8. No secrets in logs or responses.

## 7. Existing products (not assumed connected)
Dukaan/Medical, Bakery, Assistant, Poultry have owner-login endpoints but this contract does NOT use them. Hospi, Estate, Pharma, Paint, Jewel, Refill, ParchiLive, TradeBill, Car View, NetDiag: no customer-account API found, manual-only. CafeDesk deleted. SchoolHub, Marquee, SmartDine, PizzaOS: add this API in their isolated builds with conformance tests. Alpha Blue vendor bot/site and third-party software: untouched.

## 8. Semantics resolved (v1.1 freeze candidate, reconciles builder defaults)
**Time.** Every timestamp in bodies and responses is ISO-8601 UTC with `Z` and milliseconds (`2026-10-31T23:59:59.999Z`). Only the `X-SCC-Timestamp` header is unix seconds. A timestamp is an INSTANT.
**Expiry.** `expired` iff `now > max(valid_until, grace_until)` (strictly after). Within `valid_until..grace_until` the account is `active`. Products that only store calendar dates (e.g. a renewal_date): use the UTC date of the instant and treat the account as valid through the END of that UTC day. Hard rule: a product MAY lag (give up to <24h extra) but MUST NEVER expire earlier than the instant it was given.
**Grace.** Canonical field is absolute `grace_until` (instant, must be >= `valid_until`). Products that store relative grace days compute `grace_days = ceil((grace_until - valid_until) / 86400000 ms)` and must report back the EFFECTIVE `grace_until = valid_until + grace_days days` in `GET /accounts/{ref}`. The Center displays the effective value and accepts a read-back that is >= requested and < requested + 1 day.
**State precedence.** `suspended` > `expired` > `active`. `trial` is reported as `active`. A suspended-and-expired account reads `suspended`; `restore` returns 409 `entitlement_expired` until a new `valid_until` is PUT. `absent` = no account bound to the ref.
**Identity.** `external_ref` is an opaque Center-assigned string `[A-Za-z0-9_.-]{1,64}`, stable for the life of the subscription, never reused, never derived from a product's internal numeric id. The product stores it as its own alias and resolves by that alias only. To bind an EXISTING tenant, the Center's PUT may carry `local_id` (the product's own id or code). The first PUT with a ref binds it; later `local_id` that differs -> 409 `ref_conflict` (no silent rebind). PUT without `local_id` and without an existing binding creates a tenant SHELL: no users, no passwords, no logins, no data. Suspending a shell is allowed.
**Single-install products** (one deployment = one customer, e.g. SmartDine): still use a ref; the install has exactly one account; `GET /accounts` returns one item; `suspend` blocks the install's logins and sessions. Never fake multi-tenancy.
**Suspend effect.** Blocks new logins and active sessions (checked on every authenticated request, not only at login), keeps all data and passwords. `revoke-sessions` deletes live sessions only for that account.
**Secrets.** Shared secret = server env var supplied via the vault flow. If unset, the connector is disabled (404 on `/_scc/v1`), fail closed. Never generated by the product, never in DB, responses, logs or forms.
**Errors.** Codes used: missing_auth, unknown_key, bad_path, stale_timestamp, bad_nonce, bad_signature, before_store_floor, nonce_replayed, nonce_store_unavailable (503), request_id_required, request_id_conflict (409), ref_conflict (409), entitlement_expired (409), unknown_account (404), bad_json (400).

## 9. Test vectors (secret is a public test value: `scc-test-vector-secret`)
Canonical query sorts by percent-encoded key, then percent-encoded value, comparing the encoded strings byte-wise (so `%C3%A9%20x` sorts before `1`).
V0 GET /_scc/v1/health, no query, ts 1760000000, nonce 00112233445566778899aabbccddeeff, empty body
  sig a139db0b8b7dbf2775ee8d89509e4f2e13f6b85d4abf0711794e1171d8a50ae6
V1 GET /_scc/v1/accounts, raw query `b=2&a=1&a=%C3%A9 x` (same ts/nonce), canonical query `a=%C3%A9%20x&a=1&b=2`
  sig 9b2e6e29c28ffadc5b5f96c43d5f50aa271c98cb49b85843c86f9ecf696b4686
V2 POST /_scc/v1/accounts/sub-7/suspend, ts 1760000000, nonce ffeeddccbbaa99887766554433221100, body `{"request_id":"11111111-1111-4111-8111-111111111111","reason":"unpaid","actor":"user:1"}`
  body sha256 0a95233231f88f650360a162c63520133f591c5671d26a038aca07a8d61b9b2b
  sig 828dc2867a4054fcb4afd5c59f6ce3eea3b17270e50df736ab97a13fd217f279
Behavior vectors: (a) valid_until 2026-10-31T00:00:00.000Z, grace none: at 2026-10-31T00:00:00.001Z reads `expired` (instant product) or `active` until 2026-10-31T23:59:59.999Z (date-only product); never expired before 00:00:00.000Z. (b) valid_until 2026-10-31T00:00:00.000Z, grace_until 2026-11-04T12:00:00.000Z: relative-grace product stores grace_days=5 and reports grace_until 2026-11-05T00:00:00.000Z. (c) suspended + expired: state `suspended`; restore -> 409 entitlement_expired; PUT valid_until 2026-12-31T00:00:00.000Z then restore -> `active`.

**Grace is always explicit (v1.1 addendum, candidate).** The Center sends `grace_until` on every provision/sync (defaulting to `valid_until` when no grace was granted), so a product's own default grace (e.g. 7 days) cannot silently extend access. Readback and reconcile compare `grace_until` as well as `valid_until` and `state`; any difference is reported as `grace_until_differs` and a sync with a different grace readback is `mismatch`, not success.
**Grace clamp.** The Center sends effective grace = max(grace_until, valid_until). An older grace that ends before a newly extended valid_until is dropped, so a product never receives grace < valid_until (which would be a 400).

**Readback acceptance (candidate, restates section 8).** After provision, sync and in reconcile, the Center accepts a readback of valid_until/grace_until iff requested <= readback < requested + 1 day (this covers exact instants, and date-only products that report end-of-UTC-day). Earlier than requested (e.g. a date truncated to 00:00) is a `mismatch`: access state unknown, action not confirmed. Products must report the effective instants they enforce.

**Center behaviour on blocking actions (informative).** A suspend or expire request is confirmed when the readback is `suspended` or `expired` (both are blocked; precedence is suspended > expired). If the readback differs from the requested word, the Center keeps the observed state and records "access already blocked". Any non-blocked readback (`active`, `absent`) stays a mismatch.
